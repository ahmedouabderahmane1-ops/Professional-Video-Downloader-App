import "dotenv/config";
import express from "express";
import helmet from "helmet";
import rateLimit from "express-rate-limit";

const app = express();
const port = Number(process.env.PORT || 3000);

app.use(helmet());
app.use(express.json({ limit: "20kb" }));
app.use("/api/", rateLimit({ windowMs: 60_000, limit: 30 }));
app.use(express.static("public"));

function validHttpUrl(value) {
  try {
    const u = new URL(value);
    return u.protocol === "https:" || u.protocol === "http:";
  } catch { return false; }
}
function isDirectVideo(value) {
  try { return /\.(mp4|webm|ogg|mov|m4v)$/i.test(new URL(value).pathname); }
  catch { return false; }
}

app.get("/api/health", (_req, res) => res.json({ ok: true }));

app.post("/api/analyze", async (req, res) => {
  const url = req.body?.url;
  if (typeof url !== "string" || !validHttpUrl(url)) {
    return res.status(400).json({ supported: false, error: "أدخل رابطاً صالحاً." });
  }

  if (isDirectVideo(url)) {
    return res.json({
      supported: true, type: "direct-video",
      title: "ملف فيديو مباشر", previewUrl: url,
      downloadUrl: url, qualities: ["original"]
    });
  }

  if (!process.env.VIDEO_PROVIDER_URL || !process.env.VIDEO_PROVIDER_KEY) {
    return res.status(501).json({
      supported: false, code: "PROVIDER_NOT_CONFIGURED",
      error: "هذا رابط صفحة لمنصة فيديو. لم يتم ربط مزود API متوافق بعد. روابط المنصات لا تعمل تلقائياً دون تكامل مصرح به."
    });
  }

  try {
    const upstream = await fetch(process.env.VIDEO_PROVIDER_URL, {
      method: "POST",
      headers: {
        "content-type": "application/json",
        "authorization": `Bearer ${process.env.VIDEO_PROVIDER_KEY}`
      },
      body: JSON.stringify({ url }),
      signal: AbortSignal.timeout(15000)
    });
    if (!upstream.ok) {
      return res.status(502).json({ supported: false, error: "مزود الخدمة لم يقبل الرابط." });
    }
    const data = await upstream.json();
    if (typeof data?.downloadUrl !== "string" || !validHttpUrl(data.downloadUrl)) {
      return res.status(502).json({ supported: false, error: "استجابة مزود الخدمة غير صالحة." });
    }
    return res.json({
      supported: true, type: "provider",
      title: typeof data.title === "string" ? data.title : "الفيديو",
      previewUrl: typeof data.previewUrl === "string" && validHttpUrl(data.previewUrl) ? data.previewUrl : null,
      downloadUrl: data.downloadUrl,
      qualities: Array.isArray(data.qualities) ? data.qualities : ["original"]
    });
  } catch {
    return res.status(502).json({ supported: false, error: "تعذر الاتصال بمزود الخدمة." });
  }
});

app.listen(port, () => console.log(`Video Downloader running on port ${port}`));
