const $ = (id) => document.getElementById(id);
const urlInput = $("videoUrl");
const statusEl = $("status");
const result = $("result");
const preview = $("preview");
const downloadLink = $("downloadLink");

function say(message, error = false) {
  statusEl.textContent = message;
  statusEl.style.color = error ? "#d34b4b" : "";
}
function validHttpUrl(value) {
  try {
    const parsed = new URL(value);
    return ["http:", "https:"].includes(parsed.protocol);
  } catch { return false; }
}

$("pasteBtn").addEventListener("click", async () => {
  try {
    urlInput.value = await navigator.clipboard.readText();
    say("تم لصق الرابط. اضغط تحليل الرابط للمتابعة.");
  } catch {
    say("تعذر الوصول إلى الحافظة. الصق الرابط في الخانة يدوياً.", true);
  }
});

$("analyzeBtn").addEventListener("click", async () => {
  const url = urlInput.value.trim();
  if (!url || !validHttpUrl(url)) {
    say("يرجى إدخال رابط يبدأ بـ http:// أو https://.", true);
    return;
  }

  const button = $("analyzeBtn");
  button.disabled = true;
  button.textContent = "جارٍ تحليل الرابط...";
  result.classList.add("hidden");
  preview.removeAttribute("src");
  preview.load();

  try {
    const response = await fetch("/api/analyze", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ url })
    });
    const data = await response.json();

    if (!response.ok || !data.supported) {
      say(data.error || "هذا الرابط غير مدعوم حالياً.", true);
      return;
    }

    $("videoTitle").textContent = data.title || "معاينة الفيديو";
    preview.src = data.previewUrl || data.downloadUrl;
    downloadLink.href = data.downloadUrl;
    downloadLink.download = "";
    result.classList.remove("hidden");
    say("تم التعرف على الرابط. يمكنك معاينة الملف وتنزيله إذا كان متاحاً.");
    saveHistory(url);
  } catch {
    say("تعذر الاتصال بالخادم. تأكد من تشغيل Backend ثم أعد المحاولة.", true);
  } finally {
    button.disabled = false;
    button.innerHTML = 'تحليل الرابط <span>⌕</span>';
  }
});

function saveHistory(url) {
  let items = JSON.parse(localStorage.getItem("videoLinks") || "[]");
  items = [{ url, date: new Date().toLocaleString("ar") },
    ...items.filter(x => x.url !== url)].slice(0, 15);
  localStorage.setItem("videoLinks", JSON.stringify(items));
  renderHistory();
}
function renderHistory() {
  const items = JSON.parse(localStorage.getItem("videoLinks") || "[]");
  const box = $("history");
  box.replaceChildren();
  if (!items.length) {
    const p = document.createElement("p");
    p.className = "empty";
    p.textContent = "لا توجد روابط محفوظة بعد.";
    box.append(p);
    return;
  }
  items.forEach(item => {
    const row = document.createElement("div");
    row.className = "history-item";
    const link = document.createElement("div");
    link.textContent = item.url;
    const date = document.createElement("small");
    date.textContent = item.date;
    row.append(link, date);
    box.append(row);
  });
}
$("clearBtn").addEventListener("click", () => {
  localStorage.removeItem("videoLinks");
  renderHistory();
});
$("themeBtn").addEventListener("click", () => {
  document.body.classList.toggle("dark");
  const dark = document.body.classList.contains("dark");
  localStorage.setItem("videoDark", String(dark));
  $("themeBtn").textContent = dark ? "☀️" : "🌙";
});
if (localStorage.getItem("videoDark") === "true") {
  document.body.classList.add("dark");
  $("themeBtn").textContent = "☀️";
}
renderHistory();
